import React from 'react';
import { MailMessage, MailboxConfig } from '../types';
import { useNavigate } from 'react-router-dom';

interface InboxListProps {
  messages: MailMessage[];
  loading: boolean;
  mailbox: MailboxConfig | null;
}

export const InboxList: React.FC<InboxListProps> = ({ messages, loading, mailbox }) => {
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 flex flex-col items-center justify-center min-h-[400px]">
        <div className="animate-spin-slow rounded-full h-16 w-16 border-4 border-gray-100 border-t-primary mb-4"></div>
        <p className="text-gray-500 font-medium animate-pulse">Waiting for incoming emails...</p>
        <p className="text-xs text-gray-400 mt-2">Checking inbox for {mailbox ? `${mailbox.login}@${mailbox.domain}` : '...'}</p>
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 flex flex-col items-center justify-center min-h-[400px] text-center">
        <div className="bg-gray-50 p-6 rounded-full mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12 text-gray-400">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
            </svg>
        </div>
        <h3 className="text-xl font-bold text-gray-700 mb-2">Your Inbox is Empty</h3>
        <p className="text-gray-500 max-w-sm">
          Emails sent to your temporary address will appear here automatically.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden min-h-[400px]">
      <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex justify-between items-center">
        <h3 className="font-bold text-gray-700">Inbox</h3>
        <span className="bg-primary/10 text-primary text-xs font-bold px-2 py-1 rounded-full">{messages.length} Messages</span>
      </div>
      <ul className="divide-y divide-gray-50">
        {messages.map((msg) => (
          <li 
            key={msg.id} 
            onClick={() => navigate(`/email/${msg.id}`)}
            className="group hover:bg-gray-50 cursor-pointer transition p-4 md:p-6"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-1">
              <span className="font-semibold text-gray-800 group-hover:text-primary transition">{msg.from}</span>
              <span className="text-xs text-gray-400">{msg.date}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="text-gray-600 text-sm font-medium">{msg.subject || "(No Subject)"}</span>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-300 group-hover:text-primary transform group-hover:translate-x-1 transition">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};