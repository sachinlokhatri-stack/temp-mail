import React, { useState } from 'react';
import { MailboxConfig } from '../types';

interface EmailControlsProps {
  mailbox: MailboxConfig | null;
  loading: boolean;
  onRefresh: () => void;
  onChange: () => void;
  onDelete: () => void;
}

export const EmailControls: React.FC<EmailControlsProps> = ({ mailbox, loading, onRefresh, onChange, onDelete }) => {
  const [copied, setCopied] = useState(false);

  const email = mailbox ? `${mailbox.login}@${mailbox.domain}` : 'Loading...';

  const handleCopy = () => {
    if (mailbox) {
      navigator.clipboard.writeText(email);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-2xl p-6 md:p-8 transform translate-y-4 md:translate-y-8 border border-gray-100">
      
      {/* Email Display Box */}
      <div className="relative mb-8">
        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Your Temporary Email Address</label>
        <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
                <input 
                    type="text" 
                    readOnly 
                    value={email} 
                    className="w-full bg-gray-50 border-2 border-gray-200 text-gray-700 text-xl md:text-2xl font-mono py-4 px-6 rounded-lg focus:outline-none focus:border-primary transition duration-200"
                />
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2">
                   {loading && (
                     <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                   )}
                </div>
            </div>
            
            <button 
                onClick={handleCopy}
                className="bg-primary hover:bg-emerald-600 text-white font-bold py-4 px-8 rounded-lg shadow-lg hover:shadow-xl transition transform active:scale-95 flex items-center justify-center gap-2 min-w-[160px]"
            >
                {copied ? (
                    <>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                        </svg>
                        <span>Copied!</span>
                    </>
                ) : (
                    <>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 01-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 011.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 00-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375a1.125 1.125 0 01-1.125-1.125v-9.25m12 6.625v-1.875a3.375 3.375 0 00-3.375-3.375h-1.5" />
                        </svg>
                        <span>Copy</span>
                    </>
                )}
            </button>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 border-t border-gray-100 pt-6">
        <button onClick={onRefresh} className="flex flex-col items-center gap-2 group p-2 rounded-lg hover:bg-gray-50 transition">
             <div className="p-3 bg-gray-100 rounded-full group-hover:bg-blue-100 text-gray-600 group-hover:text-blue-600 transition">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                </svg>
             </div>
             <span className="text-sm font-medium text-gray-600">Refresh</span>
        </button>

        <button onClick={onChange} className="flex flex-col items-center gap-2 group p-2 rounded-lg hover:bg-gray-50 transition">
             <div className="p-3 bg-gray-100 rounded-full group-hover:bg-green-100 text-gray-600 group-hover:text-green-600 transition">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                   <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                </svg>
             </div>
             <span className="text-sm font-medium text-gray-600">Change</span>
        </button>

        <button onClick={onDelete} className="flex flex-col items-center gap-2 group p-2 rounded-lg hover:bg-gray-50 transition">
             <div className="p-3 bg-gray-100 rounded-full group-hover:bg-red-100 text-gray-600 group-hover:text-red-600 transition">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                   <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                </svg>
             </div>
             <span className="text-sm font-medium text-gray-600">Delete</span>
        </button>

        <div className="flex flex-col items-center gap-2 group p-2 rounded-lg">
           <div className="p-3">
              <span className="text-xs text-gray-400 font-mono">
                Auto Refresh: ON
              </span>
           </div>
        </div>
      </div>
    </div>
  );
};