import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
}

export const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', className = '', ...props }) => {
  let baseStyles = "px-4 py-2 rounded-lg font-medium transition duration-200 flex items-center justify-center gap-2 ";
  
  if (variant === 'primary') {
    baseStyles += "bg-primary text-white hover:bg-emerald-600 shadow-sm ";
  } else if (variant === 'secondary') {
    baseStyles += "bg-gray-800 text-white hover:bg-gray-700 ";
  } else {
    baseStyles += "border border-gray-300 text-gray-600 hover:bg-gray-50 ";
  }

  return (
    <button className={`${baseStyles} ${className}`} {...props}>
      {children}
    </button>
  );
};