import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MailService } from '../services/mailService';
import { AIService } from '../services/aiService';
import { MailboxConfig, FullMessage } from '../types';

interface EmailDetailProps {
  mailbox: MailboxConfig | null;
}

export const EmailDetail: React.FC<EmailDetailProps> = ({ mailbox }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [message, setMessage] = useState<FullMessage | null>(null);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<string | null>(null);
  const [generatingSummary, setGeneratingSummary] = useState(false);

  useEffect(() => {
    const fetchMessage = async () => {
      if (!mailbox || !id) return;
      setLoading(true);
      const msg = await MailService.getMessage(mailbox.login, mailbox.domain, parseInt(id));
      setMessage(msg);
      setLoading(false);
    };
    fetchMessage();
  }, [mailbox, id]);

  const handleSummarize = async () => {
    if (!message) return;
    setGeneratingSummary(true);
    // Use HTML body stripped of tags, or text body if available
    const content = message.textBody || message.htmlBody.replace(/<[^>]*>?/gm, '');
    const result = await AIService.summarizeEmail(message.subject, content);
    setSummary(result);
    setGeneratingSummary(false);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 flex items-center justify-center min-h-[400px]">
         <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!message) {
    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
            <h3 className="text-lg font-bold">Message not found</h3>
            <button onClick={() => navigate('/')} className="mt-4 text-primary hover:underline">Back to Inbox</button>
        </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden min-h-[600px] flex flex-col">
      {/* Header */}
      <div className="bg-gray-50 p-6 border-b border-gray-100">
         <div className="flex items-center gap-4 mb-4">
            <button 
                onClick={() => navigate('/')}
                className="p-2 hover:bg-gray-200 rounded-full transition text-gray-500"
            >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                </svg>
            </button>
            <h2 className="text-xl font-bold text-gray-800 line-clamp-1">{message.subject}</h2>
         </div>
         
         <div className="flex flex-col md:flex-row justify-between text-sm gap-2">
            <div>
                <span className="text-gray-400">From:</span> <span className="font-semibold text-gray-700 ml-1">{message.from}</span>
            </div>
            <div className="text-gray-400">
                {message.date}
            </div>
         </div>
      </div>

      {/* AI Summary Section */}
      <div className="px-6 py-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-b border-blue-100">
         <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-indigo-700 font-semibold text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                  <path fillRule="evenodd" d="M9 4.5a.75.75 0 01.721.544l.813 2.846a3.75 3.75 0 002.576 2.576l2.846.813a.75.75 0 010 1.442l-2.846.813a3.75 3.75 0 00-2.576 2.576l-.813 2.846a.75.75 0 01-1.442 0l-.813-2.846a3.75 3.75 0 00-2.576-2.576l-2.846-.813a.75.75 0 010-1.442l2.846-.813a3.75 3.75 0 002.576-2.576l.813-2.846A.75.75 0 019 4.5zM6.97 11.03a.75.75 0 111.06 1.06l-1.06 1.06a.75.75 0 11-1.06-1.06l1.06-1.06z" clipRule="evenodd" />
                </svg>
                AI Assistant
            </div>
            {!summary && (
                <button 
                    onClick={handleSummarize}
                    disabled={generatingSummary}
                    className="text-xs bg-white text-indigo-600 border border-indigo-200 px-3 py-1 rounded-full hover:bg-indigo-50 transition flex items-center gap-1 disabled:opacity-50"
                >
                    {generatingSummary ? 'Thinking...' : 'Summarize Email'}
                </button>
            )}
         </div>
         {summary && (
             <div className="text-sm text-indigo-800 leading-relaxed bg-white/50 p-3 rounded-lg border border-indigo-100">
                 {summary}
             </div>
         )}
      </div>

      {/* Body */}
      <div className="flex-grow p-6 overflow-y-auto bg-white">
         {/* Sanitize and render HTML content carefully. 
             In a production app, use DOMPurify. For this example, we use a simple iframe or dangerouslySetInnerHTML responsibly.
             Since it's a demo, we will use a sandboxed iframe for security.
          */}
          <iframe 
            title="email-content"
            srcDoc={message.htmlBody || message.textBody}
            className="w-full h-full min-h-[400px] border-none"
            sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin"
          />
      </div>

      {/* Attachments (Mock) */}
      {message.attachments && message.attachments.length > 0 && (
         <div className="p-4 border-t border-gray-100 bg-gray-50">
            <h4 className="text-sm font-semibold text-gray-600 mb-2">Attachments</h4>
            <div className="flex flex-wrap gap-2">
               {message.attachments.map((att, idx) => (
                   <div key={idx} className="flex items-center gap-2 bg-white border border-gray-200 px-3 py-2 rounded text-sm text-gray-600">
                       <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
                         <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.112 2.13" />
                       </svg>
                       {att.filename} <span className="text-gray-400 text-xs">({Math.round(att.size / 1024)} KB)</span>
                   </div>
               ))}
            </div>
         </div>
      )}
    </div>
  );
};