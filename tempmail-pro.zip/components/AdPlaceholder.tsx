import React from 'react';

interface AdPlaceholderProps {
  size: 'vertical' | 'square' | 'banner';
}

export const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ size }) => {
  let classes = "bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-400 text-xs font-mono uppercase tracking-widest";
  
  if (size === 'vertical') {
    classes += " w-full h-[600px]";
  } else if (size === 'square') {
    classes += " w-full h-[250px]";
  } else {
    classes += " w-full h-[90px]";
  }

  return (
    <div className={classes}>
      Advertisement
      {/* 
        To Integrate AdSense later:
        1. Replace this div with the <ins> tag provided by Google.
        2. Ensure the script is loaded in index.html
      */}
    </div>
  );
};