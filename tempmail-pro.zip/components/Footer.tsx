import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary text-gray-400 py-12 mt-auto">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="col-span-1 md:col-span-2">
           <h4 className="text-white font-bold text-lg mb-4">TempMail Pro</h4>
           <p className="text-sm leading-relaxed mb-4">
             Temporary Disposable Email Address service to protect your privacy. 
             Emails are deleted automatically after a set period of time.
           </p>
           <p className="text-xs">&copy; {new Date().getFullYear()} TempMail Pro. All rights reserved.</p>
        </div>
        
        <div>
          <h5 className="text-white font-semibold mb-3">Links</h5>
          <ul className="space-y-2 text-sm">
            <li><a href="#" className="hover:text-primary">Home</a></li>
            <li><a href="#" className="hover:text-primary">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-primary">Terms of Service</a></li>
            <li><a href="#" className="hover:text-primary">FAQ</a></li>
          </ul>
        </div>

        <div>
          <h5 className="text-white font-semibold mb-3">Contact</h5>
          <ul className="space-y-2 text-sm">
            <li><a href="#" className="hover:text-primary">Support</a></li>
            <li><a href="#" className="hover:text-primary">Feedback</a></li>
            <li><a href="#" className="hover:text-primary">Partners</a></li>
          </ul>
        </div>
      </div>
    </footer>
  );
};