export const API_BASE_URL = 'https://www.1secmail.com/api/v1/';

export const MOCK_DOMAINS = [
  '1secmail.com',
  '1secmail.org',
  '1secmail.net'
];

export const APP_NAME = "TempMail Pro";