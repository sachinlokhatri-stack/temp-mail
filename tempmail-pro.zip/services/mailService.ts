import { API_BASE_URL, MOCK_DOMAINS } from '../constants';
import { MailboxConfig, MailMessage, FullMessage } from '../types';

export class MailService {
  private static STORAGE_KEY = 'temp_mail_config';

  static async generateRandomMailbox(): Promise<MailboxConfig> {
    // 1secmail allows us to just make up an address, but they also have a generator endpoint.
    // We will use the generator endpoint to get valid active domains.
    try {
      const response = await fetch(`${API_BASE_URL}?action=genRandomMailbox&count=1`);
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      const email = data[0]; // e.g., "x7s8d@1secmail.com"
      const [login, domain] = email.split('@');
      
      const config = { login, domain };
      this.saveMailbox(config);
      return config;
    } catch (error) {
      // Fallback if API fails
      const fallback = {
        login: Math.random().toString(36).substring(2, 10),
        domain: MOCK_DOMAINS[0]
      };
      this.saveMailbox(fallback);
      return fallback;
    }
  }

  static getStoredMailbox(): MailboxConfig | null {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    return stored ? JSON.parse(stored) : null;
  }

  static saveMailbox(config: MailboxConfig) {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(config));
  }

  static async getMessages(login: string, domain: string): Promise<MailMessage[]> {
    try {
      const response = await fetch(`${API_BASE_URL}?action=getMessages&login=${login}&domain=${domain}`);
      if (!response.ok) return [];
      const data = await response.json();
      return data as MailMessage[];
    } catch (error) {
      console.error("Error fetching messages:", error);
      return [];
    }
  }

  static async getMessage(login: string, domain: string, id: number): Promise<FullMessage | null> {
    try {
      const response = await fetch(`${API_BASE_URL}?action=readMessage&login=${login}&domain=${domain}&id=${id}`);
      if (!response.ok) return null;
      const data = await response.json();
      return data as FullMessage;
    } catch (error) {
      console.error("Error fetching message details:", error);
      return null;
    }
  }
}