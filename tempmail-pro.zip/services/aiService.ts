import { GoogleGenAI } from "@google/genai";

export class AIService {
  private static ai: GoogleGenAI | null = null;

  private static getAI() {
    if (!this.ai && process.env.API_KEY) {
      this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return this.ai;
  }

  static async summarizeEmail(subject: string, body: string): Promise<string> {
    const ai = this.getAI();
    if (!ai) {
      return "AI Service is not configured (Missing API Key).";
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Please provide a concise summary (max 2 sentences) of the following email. 
        
        Subject: ${subject}
        Body: ${body}
        `,
      });
      return response.text || "Could not generate summary.";
    } catch (error) {
      console.error("AI Summarization failed:", error);
      return "Failed to generate summary due to an error.";
    }
  }
}