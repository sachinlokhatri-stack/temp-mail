export interface MailboxConfig {
  login: string;
  domain: string;
}

export interface MailMessage {
  id: number;
  from: string;
  subject: string;
  date: string;
}

export interface FullMessage extends MailMessage {
  textBody: string;
  htmlBody: string;
  attachments: Attachment[];
}

export interface Attachment {
  filename: string;
  contentType: string;
  size: number;
}

export enum LoadState {
  IDLE = 'idle',
  LOADING = 'loading',
  SUCCESS = 'success',
  ERROR = 'error'
}