import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { EmailControls } from './components/EmailControls';
import { InboxList } from './components/InboxList';
import { EmailDetail } from './components/EmailDetail';
import { AdPlaceholder } from './components/AdPlaceholder';
import { MailService } from './services/mailService';
import { MailMessage, MailboxConfig } from './types';

// Wrapper to handle layout based on routes
const MainLayout: React.FC = () => {
  const [mailbox, setMailbox] = useState<MailboxConfig | null>(null);
  const [messages, setMessages] = useState<MailMessage[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [autoRefresh, setAutoRefresh] = useState<boolean>(true);

  // Initialize mailbox on load
  useEffect(() => {
    const initMailbox = async () => {
      const stored = MailService.getStoredMailbox();
      if (stored) {
        setMailbox(stored);
      } else {
        const newMailbox = await MailService.generateRandomMailbox();
        setMailbox(newMailbox);
      }
    };
    initMailbox();
  }, []);

  // Poll for messages
  const checkMessages = useCallback(async () => {
    if (!mailbox) return;
    try {
      // Don't set loading true for background polling to avoid UI flicker
      const msgs = await MailService.getMessages(mailbox.login, mailbox.domain);
      // Only update if count changes to avoid unnecessary re-renders or checks
      setMessages(prev => {
        if (prev.length !== msgs.length || (msgs.length > 0 && prev.length > 0 && msgs[0].id !== prev[0].id)) {
          return msgs;
        }
        return prev;
      });
    } catch (error) {
      console.error("Failed to check messages", error);
    }
  }, [mailbox]);

  useEffect(() => {
    // Initial check
    checkMessages();

    if (!autoRefresh) return;

    const interval = setInterval(() => {
      checkMessages();
    }, 5000); // Check every 5 seconds

    return () => clearInterval(interval);
  }, [mailbox, autoRefresh, checkMessages]);

  const handleRefresh = async () => {
    setLoading(true);
    await checkMessages();
    setLoading(false);
  };

  const handleChangeEmail = async () => {
    setLoading(true);
    setMessages([]);
    const newMailbox = await MailService.generateRandomMailbox();
    setMailbox(newMailbox);
    setLoading(false);
  };

  const handleDeleteMailbox = async () => {
     // For a temp mail, "delete" just means get a new one usually
     await handleChangeEmail();
  }

  const location = useLocation();
  const isDetailPage = location.pathname.includes('/email/');

  return (
    <main className="flex-grow flex flex-col items-center w-full">
      {/* Hero Section with Email Controls */}
      <section className="w-full bg-secondary pt-24 pb-12 px-4 rounded-b-[3rem] shadow-xl relative overflow-hidden">
        {/* Abstract Background Patterns */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10 pointer-events-none">
             <div className="absolute -top-24 -left-24 w-64 h-64 rounded-full bg-primary blur-3xl"></div>
             <div className="absolute top-1/2 right-0 w-96 h-96 rounded-full bg-accent blur-3xl"></div>
        </div>

        <div className="max-w-4xl mx-auto w-full relative z-10">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
              Your Temporary Email Address
            </h1>
            <p className="text-gray-400 text-lg">
              Forget about spam, advertising mailings, hacking and attacking robots. 
              Keep your real mailbox clean and secure.
            </p>
          </div>
          
          <EmailControls 
            mailbox={mailbox} 
            loading={loading}
            onRefresh={handleRefresh}
            onChange={handleChangeEmail}
            onDelete={handleDeleteMailbox}
          />
        </div>
      </section>

      {/* Main Content Area */}
      <div className="max-w-6xl w-full mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Sidebar / Ads */}
        <div className="lg:col-span-3 hidden lg:flex flex-col gap-6">
           <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 h-full">
              <h3 className="font-semibold text-gray-700 mb-4">Why use Temp Mail?</h3>
              <ul className="text-sm text-gray-600 space-y-3">
                <li className="flex items-start"><span className="mr-2 text-primary">✓</span> No registration</li>
                <li className="flex items-start"><span className="mr-2 text-primary">✓</span> Completely anonymous</li>
                <li className="flex items-start"><span className="mr-2 text-primary">✓</span> Data is encrypted</li>
                <li className="flex items-start"><span className="mr-2 text-primary">✓</span> Avoid spam</li>
              </ul>
           </div>
           <AdPlaceholder size="vertical" />
        </div>

        {/* Center Content: Inbox or Email Detail */}
        <div className="lg:col-span-6 flex flex-col gap-6">
          <Routes>
            <Route 
              path="/" 
              element={
                <InboxList 
                  messages={messages} 
                  loading={loading && messages.length === 0} 
                  mailbox={mailbox}
                />
              } 
            />
            <Route 
              path="/email/:id" 
              element={<EmailDetail mailbox={mailbox} />} 
            />
          </Routes>
        </div>

        {/* Right Sidebar / Ads */}
        <div className="lg:col-span-3 flex flex-col gap-6">
           <AdPlaceholder size="square" />
           <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-700 mb-2">Premium Features</h3>
              <p className="text-xs text-gray-500 mb-4">
                Unlock custom domains and premium support. (Mock)
              </p>
              <button className="w-full py-2 bg-gray-100 text-gray-600 text-sm font-medium rounded hover:bg-gray-200 transition">
                Go Premium
              </button>
           </div>
        </div>
      </div>
      
      {/* SEO Content Block (Bottom) */}
      {!isDetailPage && (
        <section className="max-w-4xl mx-auto px-4 py-12 text-gray-600">
           <h2 className="text-2xl font-bold text-gray-800 mb-4">What is a Disposable Temporary Email?</h2>
           <p className="mb-4">
             Disposable email - is a free email service that allows to receive email at a temporary address that self-destructed after a certain time elapses. 
             It is also known by names like : tempmail, 10minutemail, 10minmail, throwaway email, fake-mail, fake email generator, burner mail or trash-mail.
           </p>
           <p>
             Many forums, Wi-Fi owners, websites and blogs ask visitors to register before they can view content, post comments or download something. 
             Temp-Mail is the most advanced throwaway email service that helps you avoid spam and stay safe.
           </p>
        </section>
      )}
    </main>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <MainLayout />
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;